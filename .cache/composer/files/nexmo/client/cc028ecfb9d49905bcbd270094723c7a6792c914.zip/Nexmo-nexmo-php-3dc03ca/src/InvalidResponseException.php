<?php

namespace Nexmo;

class InvalidResponseException extends \Exception {

}
